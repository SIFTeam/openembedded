#ifndef XONAR_DG_H_INCLUDED
#define XONAR_DG_H_INCLUDED

#include "oxygen.h"

extern struct oxygen_model model_xonar_dg;

#endif
