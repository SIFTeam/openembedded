extern int mod_firmware_load(const char *fn, char **fp);

